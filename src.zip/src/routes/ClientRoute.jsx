// src/routes/ClientRoute.jsx
import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ClientRoute({ children }) {
  const { currentUser, role } = useAuth();

  if (!currentUser) return <Navigate to="/login" replace />;
  if (role !== "client") return <Navigate to="/admin" replace />;

  return children;
}
