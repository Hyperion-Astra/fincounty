import React, { useEffect, useState } from "react";
import { db } from "../../firebase";
import { doc, getDoc } from "firebase/firestore";
import { useAuth } from "../../context/AuthContext";
import DashboardCard from "../../components/DashboardCard";

export default function ClientDashboard() {
  const { user } = useAuth();
  const [wallet, setWallet] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadWallet() {
      try {
        if (!user) return;
        const ref = doc(db, "users", user.uid);
        const snap = await getDoc(ref);

        if (snap.exists()) {
          setWallet(snap.data().wallet || 0);
        }
      } catch (e) {
        console.error("Wallet load error", e);
      }
      setLoading(false);
    }
    loadWallet();
  }, [user]);

  if (loading) return <div className="center-loading">Loading...</div>;

  return (
    <div className="client-dashboard">

      <div className="dash-grid">

        <DashboardCard
          title="Wallet Balance"
          value={`$${wallet.toLocaleString()}`}
          color="primary"
        />

        <DashboardCard
          title="Active Loans"
          value="0"
          color="secondary"
        />

        <DashboardCard
          title="Pending Withdrawals"
          value="0"
          color="orange"
        />

      </div>

      <div className="dash-section">
        <h3>Recent Activity</h3>
        <div className="empty-state">No recent transactions</div>
      </div>

    </div>
  );
}

