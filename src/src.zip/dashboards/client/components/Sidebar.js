// src/dashboards/client/components/Sidebar.js
import React from "react";
import { NavLink } from "react-router-dom";
import { FiHome, FiCreditCard, FiSend, FiUser, FiLogOut } from "react-icons/fi";
import { useContext } from "react";
import { AuthContext } from "../../../context/AuthContext";

const Sidebar = () => {
  const { logout } = useContext(AuthContext);

  return (
    <aside className="client-sidebar">
      <div className="sidebar-header">Client Dashboard</div>

      <nav className="sidebar-nav">
        <NavLink to="/client" end><FiHome /> Dashboard</NavLink>
        <NavLink to="/client/loans"><FiCreditCard /> Loans</NavLink>
        <NavLink to="/client/withdraw"><FiSend /> Withdraw</NavLink>
        <NavLink to="/client/profile"><FiUser /> Profile</NavLink>
      </nav>

      <button className="sidebar-logout" onClick={logout}>
        <FiLogOut /> Logout
      </button>
    </aside>
  );
};

export default Sidebar;
