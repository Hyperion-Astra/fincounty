// src/dashboards/client/ClientLayout.jsx
import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import "../../dashboards/dashboard.css";

export default function ClientLayout() {
  const { user } = useAuth();

  if (!user || user.role !== "client") {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="client-layout">
      <Sidebar />

      <div className="client-content">
        <Topbar />

        <main className="client-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
