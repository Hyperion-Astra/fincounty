// src/dashboard/client/Withdraw.jsx
import React, { useState } from "react";
import { submitWithdrawalRequest } from "../../utils/transactionHelpers";
import "./Withdraw.css";

export default function Withdraw() {
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleWithdraw(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    if (!amount || Number(amount) <= 0) {
      setMessage("Enter a valid amount.");
      setLoading(false);
      return;
    }

    try {
      await submitWithdrawalRequest(Number(amount));
      setMessage("Withdrawal request submitted and awaiting approval.");
      setAmount("");
    } catch (err) {
      console.error(err);
      setMessage("Error submitting withdrawal request.");
    }

    setLoading(false);
  }

  return (
    <div className="withdraw-page">
      <h2>Request Withdrawal</h2>

      <form className="withdraw-form" onSubmit={handleWithdraw}>
        <label>Amount</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter withdrawal amount"
        />

        <button type="submit" disabled={loading}>
          {loading ? "Processing..." : "Submit Request"}
        </button>
      </form>

      {message && <p className="withdraw-msg">{message}</p>}
    </div>
  );
}
