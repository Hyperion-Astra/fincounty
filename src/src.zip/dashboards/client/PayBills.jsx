const PayBills = () => {
  return <div>Pay your bills here</div>;
};

export default PayBills;
