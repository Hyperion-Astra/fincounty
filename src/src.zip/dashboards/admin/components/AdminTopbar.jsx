// src/dashboards/admin/components/AdminTopbar.js
import React from "react";
import { FiMenu } from "react-icons/fi";

const AdminTopbar = ({ toggleSidebar }) => {
  return (
    <header className="admin-topbar">
      <button className="menu-btn" onClick={toggleSidebar}>
        <FiMenu size={20} />
      </button>
      <h1 className="topbar-title">Admin Dashboard</h1>
    </header>
  );
};

export default AdminTopbar;
