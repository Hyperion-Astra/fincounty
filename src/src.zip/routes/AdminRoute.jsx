// src/routes/AdminRoute.js
import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function AdminRoute({ children }) {
  const { user, userData, loading } = useAuth();

  if (loading) return null;

  if (!user || !userData) {
    return <Navigate to="/login" replace />;
  }

  if (userData.role !== "admin") {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}
